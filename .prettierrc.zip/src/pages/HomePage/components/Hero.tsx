export default function Hero() {
  return (
    <section>
      edit <i>src/pages/HomePage/...r</i>
    </section>
  );
}
