import Default from "./Default";

const Layout = { Default };

export default Layout;
