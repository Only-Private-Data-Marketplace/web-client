export default function Navbar() {
  return <nav></nav>;
}
